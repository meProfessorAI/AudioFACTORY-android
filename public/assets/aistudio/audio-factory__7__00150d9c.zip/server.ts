/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 * AudioFACTORY Full-Stack Server
 */
import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { createServer as createViteServer } from 'vite';

// Load .env and .env.local files into process.env
['.env', '.env.local'].forEach(file => {
  const p = path.resolve(process.cwd(), file);
  if (fs.existsSync(p)) {
    try {
      if (typeof (process as any).loadEnvFile === 'function') {
        (process as any).loadEnvFile(p);
      } else {
        const content = fs.readFileSync(p, 'utf-8');
        content.split('\n').forEach(line => {
          const trimmed = line.trim();
          if (trimmed && !trimmed.startsWith('#')) {
            const eqIdx = trimmed.indexOf('=');
            if (eqIdx > 0) {
              const key = trimmed.slice(0, eqIdx).trim();
              const val = trimmed.slice(eqIdx + 1).trim();
              if (!process.env[key]) {
                process.env[key] = val;
              }
            }
          }
        });
      }
    } catch (_) {}
  }
});

import { apiRouter } from './backend/routes';
import { firebaseAuthProxyMiddleware } from './backend/firebaseAuthProxy';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middlewares
  app.use(cors());
  app.use(express.json({ limit: '50mb' }));
  app.use(express.urlencoded({ extended: true, limit: '50mb' }));

  // Same-origin Firebase Authentication helper reverse proxy (/__/auth/** & /__/firebase/**)
  app.use('/__/auth', firebaseAuthProxyMiddleware);
  app.use('/__/firebase', firebaseAuthProxyMiddleware);

  // Request logger for diagnostic tracing (redacting auth query tokens)
  app.use((req, _res, next) => {
    if (req.path.startsWith('/api')) {
      console.log(`[API ${req.method}] ${req.path}`);
    }
    next();
  });

  // Mount API routes first
  app.use('/api', apiRouter);

  // Serve dedicated marketing website at /website and /marketing
  const websitePath = path.join(process.cwd(), 'website');
  app.use('/website', express.static(websitePath));
  app.get('/marketing', (_req, res) => {
    res.sendFile(path.join(websitePath, 'index.html'));
  });

  // Vite middleware in dev / static serve in prod
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AudioFACTORY Full-Stack Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
